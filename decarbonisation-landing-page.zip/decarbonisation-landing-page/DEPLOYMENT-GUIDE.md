# Deployment Guide: Decarbonisation Industrial Landing Page

This guide will walk you through deploying your landing page to the internet and connecting it to your Namecheap domain.

## 🎯 Recommended Approach: Netlify

For complete beginners, Netlify is the easiest option. Here's the step-by-step process:

### Step 1: Prepare Your Files

1. **Download/Copy** the entire `decarbonisation-landing-page` folder to your computer
2. **Replace the logo** (optional): Replace `assets/images/logo-placeholder.svg` with your actual logo
3. **Test locally**: Open `index.html` in your web browser to verify everything looks correct

### Step 2: Deploy to Netlify

1. **Create Account**:
   - Go to [netlify.com](https://netlify.com)
   - Click "Sign up" and create a free account
   - You can sign up with email or GitHub

2. **Deploy Your Site**:
   - Once logged in, you'll see the Netlify dashboard
   - Look for the area that says "Want to deploy a new site without connecting to Git?"
   - **Drag and drop** your entire `decarbonisation-landing-page` folder into this area
   - Netlify will automatically upload and deploy your site

3. **Get Your Temporary URL**:
   - After deployment, Netlify will give you a temporary URL like `amazing-site-123456.netlify.app`
   - Click this URL to test your live site
   - Verify that everything works correctly

### Step 3: Connect Your Custom Domain

1. **Add Custom Domain**:
   - In your Netlify dashboard, click on your site
   - Go to "Site settings" → "Domain management"
   - Click "Add custom domain"
   - Enter: `decarbonisationindustrial.com`
   - Click "Verify" and then "Add domain"

2. **Configure DNS in Namecheap**:
   - Log into your Namecheap account
   - Go to "Domain List" and click "Manage" next to your domain
   - Click on the "Nameservers" section
   - Change from "Namecheap BasicDNS" to "Custom DNS"
   - Enter these Netlify nameservers (Netlify will provide the exact ones in your dashboard):
     - `dns1.p01.nsone.net`
     - `dns2.p01.nsone.net`
     - `dns3.p01.nsone.net`
     - `dns4.p01.nsone.net`

3. **Wait for DNS Propagation**:
   - DNS changes can take 24-48 hours to fully propagate
   - Your site will be accessible at your custom domain once this completes
   - Netlify will automatically provision an SSL certificate (HTTPS)

### Step 4: Test Your Live Site

1. **Check Functionality**:
   - Visit `https://decarbonisationindustrial.com`
   - Test the contact form by submitting a message
   - Verify the site works on mobile devices
   - Check that all links and images load correctly

2. **Form Notifications**:
   - In Netlify dashboard, go to "Forms" to see form submissions
   - Set up email notifications in "Site settings" → "Forms" → "Form notifications"

## 🔄 Alternative: GitHub Pages

If you prefer GitHub Pages (completely free forever):

### Step 1: Create GitHub Account

1. Go to [github.com](https://github.com) and create a free account
2. Verify your email address

### Step 2: Create Repository

1. Click the "+" icon in the top right and select "New repository"
2. Name it something like `decarbonisation-landing-page`
3. Make it public (required for free GitHub Pages)
4. Check "Add a README file"
5. Click "Create repository"

### Step 3: Upload Files

1. In your new repository, click "uploading an existing file"
2. Drag all files from your `decarbonisation-landing-page` folder
3. Write a commit message like "Initial landing page upload"
4. Click "Commit changes"

### Step 4: Enable GitHub Pages

1. Go to repository "Settings" (tab at the top)
2. Scroll down to "Pages" in the left sidebar
3. Under "Source", select "Deploy from a branch"
4. Choose "main" branch and "/ (root)"
5. Click "Save"

### Step 5: Configure Custom Domain

1. In the Pages settings, add your custom domain: `decarbonisationindustrial.com`
2. This creates a CNAME file in your repository

### Step 6: Update Namecheap DNS

1. Log into Namecheap and go to "Domain List" → "Manage"
2. Click "Advanced DNS"
3. Add these A records for "@":
   - `185.199.108.153`
   - `185.199.109.153`
   - `185.199.110.153`
   - `185.199.111.153`
4. Add CNAME record for "www" pointing to `yourusername.github.io`

## 📧 Contact Form Setup

### For Netlify (Automatic)
- Forms work automatically with the existing code
- Check "Forms" in your Netlify dashboard to see submissions
- Set up email notifications in site settings

### For GitHub Pages (Requires Third-Party Service)
1. Sign up for a form service like [Formspree](https://formspree.io) or [Getform](https://getform.io)
2. Update the form action in `index.html` with your form endpoint
3. Configure email notifications in the form service

## 🔧 Troubleshooting

### Common Issues

**"Site not loading"**
- Check DNS propagation at [whatsmydns.net](https://whatsmydns.net)
- Wait up to 48 hours for full propagation
- Verify DNS records are correct

**"Form not working"**
- For Netlify: Ensure `data-netlify="true"` is in the form tag
- For GitHub Pages: Set up a third-party form service
- Check browser console for JavaScript errors

**"Images not loading"**
- Verify file paths are correct
- Check that image files were uploaded properly
- Ensure file names match exactly (case-sensitive)

**"Site looks broken on mobile"**
- Clear browser cache
- Test in different browsers
- Verify CSS file is loading correctly

### Getting Help

1. **Netlify**: Check their [documentation](https://docs.netlify.com) or support
2. **GitHub Pages**: Visit [GitHub Pages documentation](https://docs.github.com/en/pages)
3. **Namecheap**: Use their support chat or knowledge base
4. **General**: Search for your specific error message online

## 🚀 Going Live Checklist

Before announcing your website:

- [ ] Test on desktop and mobile devices
- [ ] Verify contact form works and you receive notifications
- [ ] Check all links and images load correctly
- [ ] Confirm HTTPS is working (green lock icon)
- [ ] Test loading speed
- [ ] Verify domain redirects (www and non-www versions)
- [ ] Submit a test contact form to ensure you receive it

## 🔄 Making Updates

### For Netlify
1. Edit files on your computer
2. Drag the updated folder to Netlify (it will overwrite)
3. Changes go live immediately

### For GitHub Pages
1. Edit files in the GitHub repository (or upload new versions)
2. Commit changes
3. GitHub automatically rebuilds and deploys

## 📈 Next Steps

Once your landing page is live:

1. **Analytics**: Add Google Analytics to track visitors
2. **SEO**: Submit your site to Google Search Console
3. **Monitoring**: Set up uptime monitoring
4. **Backup**: Keep local copies of your files
5. **Updates**: Plan regular content updates as your company evolves

---

**Congratulations!** Your professional landing page is now ready for the world. Your stealth mode presence is established and ready to attract the right stakeholders in the industrial decarbonization sector.

