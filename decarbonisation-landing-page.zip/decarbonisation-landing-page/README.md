# Decarbonisation Industrial - Landing Page

A professional stealth mode landing page for decarbonisationindustrial.com, built with modern web standards and optimized for performance and accessibility.

## 🚀 Quick Start

This landing page is ready for deployment to any static hosting service. The recommended approach for beginners is **Netlify** due to its ease of use.

### Files Included

```
decarbonisation-landing-page/
├── index.html              # Main HTML file
├── assets/
│   ├── styles.css          # Complete CSS styling
│   ├── script.js           # JavaScript functionality
│   └── images/
│       └── logo-placeholder.svg  # Placeholder logo (replace with your logo)
└── README.md               # This file
```

## 🎯 Features

✅ **Professional Design** - Clean, modern layout with sustainability-focused color scheme  
✅ **Stealth Mode Messaging** - Appropriate confidentiality while maintaining credibility  
✅ **Contact Form** - Netlify-ready form with validation and spam protection  
✅ **Responsive Design** - Works perfectly on desktop, tablet, and mobile  
✅ **Fast Loading** - Optimized for performance with minimal dependencies  
✅ **Accessible** - Follows web accessibility standards  
✅ **SEO Ready** - Proper meta tags and semantic HTML structure  

## 📱 Mobile Responsive

The landing page automatically adapts to different screen sizes:
- **Desktop**: Full layout with side-by-side elements
- **Tablet**: Adjusted spacing and typography
- **Mobile**: Stacked layout optimized for touch interaction

## 🔧 Customization

### Replace the Logo

1. Replace `assets/images/logo-placeholder.svg` with your company logo
2. Supported formats: SVG (recommended), PNG, or JPG
3. Recommended size: 48px height for optimal display

### Update Contact Email

The contact form and email link use `contact@decarbonisationindustrial.com`. Update this in:
- Line 108 in `index.html` (email link)
- Your actual email setup when deploying

### Modify Content

All content can be edited directly in `index.html`:
- Company name and messaging
- Industry context information
- Contact form fields
- Footer information

## 🚀 Deployment Options

### Option 1: Netlify (Recommended for Beginners)

1. **Create Account**: Go to [netlify.com](https://netlify.com) and sign up
2. **Deploy**: Drag the entire `decarbonisation-landing-page` folder to Netlify's deploy area
3. **Custom Domain**: Add your domain in Site Settings > Domain Management
4. **DNS Setup**: Update your Namecheap DNS settings (see instructions below)

### Option 2: GitHub Pages

1. **Create Repository**: Upload files to a new GitHub repository
2. **Enable Pages**: Go to Settings > Pages in your repository
3. **Custom Domain**: Add your domain in the Pages settings
4. **DNS Setup**: Configure DNS records in Namecheap (see instructions below)

### Option 3: Vercel

1. **Create Account**: Sign up at [vercel.com](https://vercel.com)
2. **Import Project**: Connect your GitHub repository or upload files
3. **Custom Domain**: Add domain in Project Settings
4. **DNS Setup**: Follow Vercel's DNS instructions

## 🌐 Domain Connection (Namecheap)

### For Netlify

**Option A: Use Netlify DNS (Easiest)**
1. In Netlify, go to Domain Settings
2. Copy the nameserver addresses provided
3. In Namecheap, go to Domain List > Manage > Nameservers
4. Change to "Custom DNS" and enter Netlify's nameservers

**Option B: Keep Namecheap DNS**
1. In Namecheap, go to Advanced DNS
2. Add A record: `@` pointing to Netlify's IP (check Netlify docs for current IP)
3. Add CNAME record: `www` pointing to your Netlify subdomain

### For GitHub Pages

1. In Namecheap, go to Advanced DNS
2. Add these A records for `@`:
   - 185.199.108.153
   - 185.199.109.153
   - 185.199.110.153
   - 185.199.111.153
3. Add CNAME record: `www` pointing to `yourusername.github.io`

## 📧 Contact Form Setup

The contact form is pre-configured for Netlify's form handling:
- Automatic spam protection
- Email notifications
- Form submission storage
- No backend required

For other hosting platforms, you may need to:
1. Set up a form handling service (Formspree, Getform, etc.)
2. Update the form action in `index.html`
3. Configure email notifications

## 🔍 SEO Optimization

The landing page includes:
- Proper meta tags for search engines
- Semantic HTML structure
- Fast loading times
- Mobile-friendly design
- Descriptive alt text for images

## 🛡️ Security Features

- HTTPS enforced (automatic with modern hosting)
- Form spam protection
- No external dependencies that could compromise security
- Clean, minimal codebase

## 📊 Performance

The landing page is optimized for speed:
- Minimal CSS and JavaScript
- Optimized images
- No external dependencies
- Fast loading fonts from Google Fonts

## 🎨 Design System

### Colors
- Primary Green: `#2d5a3d` (sustainability theme)
- Secondary Green: `#4a7c59`
- Accent Blue: `#1e3a8a`
- Light backgrounds and professional grays

### Typography
- Font: Inter (modern, readable)
- Responsive sizing
- Clear hierarchy

### Layout
- Clean, minimal design
- Professional spacing
- Card-based information architecture

## 🔧 Technical Details

- **HTML5**: Semantic markup for accessibility and SEO
- **CSS3**: Modern features like Grid and Flexbox
- **Vanilla JavaScript**: No frameworks, fast loading
- **Progressive Enhancement**: Works without JavaScript
- **Cross-browser Compatible**: Tested in major browsers

## 📞 Support

If you need help with deployment or customization:
1. Check the comprehensive guide provided separately
2. Consult your hosting platform's documentation
3. Consider hiring a web developer for advanced customizations

## 📝 License

This landing page template is created for Decarbonisation Industrial. Modify as needed for your business requirements.

---

**Ready to deploy?** Choose your hosting platform and follow the deployment instructions above. Your professional landing page will be live within hours!

