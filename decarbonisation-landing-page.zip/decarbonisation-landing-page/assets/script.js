// Enhanced functionality for the landing page
document.addEventListener('DOMContentLoaded', function() {
    
    // Form handling and validation
    const contactForm = document.querySelector('.contact-form');
    const submitButton = document.querySelector('.submit-button');
    const formInputs = document.querySelectorAll('.form-input, .form-textarea');
    
    // Logo placeholder handling
    const logo = document.getElementById('company-logo');
    
    // Handle logo error (if user hasn't uploaded their logo yet)
    logo.addEventListener('error', function() {
        // Create a placeholder logo
        const placeholder = document.createElement('div');
        placeholder.className = 'logo-placeholder';
        placeholder.innerHTML = 'DI';
        placeholder.style.cssText = `
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, #2d5a3d 0%, #4a7c59 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            font-weight: 700;
            font-size: 18px;
            letter-spacing: -0.5px;
        `;
        
        // Replace the broken image with placeholder
        logo.parentNode.replaceChild(placeholder, logo);
    });
    
    // Enhanced form validation
    function validateForm() {
        let isValid = true;
        const requiredFields = document.querySelectorAll('[required]');
        
        requiredFields.forEach(field => {
            const value = field.value.trim();
            const fieldGroup = field.closest('.form-group');
            
            // Remove existing error styling
            field.classList.remove('error');
            const existingError = fieldGroup.querySelector('.error-message');
            if (existingError) {
                existingError.remove();
            }
            
            // Validate field
            if (!value) {
                isValid = false;
                showFieldError(field, 'This field is required');
            } else if (field.type === 'email' && !isValidEmail(value)) {
                isValid = false;
                showFieldError(field, 'Please enter a valid email address');
            }
        });
        
        return isValid;
    }
    
    function showFieldError(field, message) {
        field.classList.add('error');
        const fieldGroup = field.closest('.form-group');
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        errorElement.textContent = message;
        errorElement.style.cssText = `
            color: #dc2626;
            font-size: 0.875rem;
            margin-top: 0.25rem;
        `;
        fieldGroup.appendChild(errorElement);
    }
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Real-time validation feedback
    formInputs.forEach(input => {
        input.addEventListener('blur', function() {
            if (this.hasAttribute('required')) {
                const value = this.value.trim();
                const fieldGroup = this.closest('.form-group');
                const existingError = fieldGroup.querySelector('.error-message');
                
                // Clear previous errors
                this.classList.remove('error');
                if (existingError) {
                    existingError.remove();
                }
                
                // Validate on blur
                if (!value) {
                    showFieldError(this, 'This field is required');
                } else if (this.type === 'email' && !isValidEmail(value)) {
                    showFieldError(this, 'Please enter a valid email address');
                } else {
                    this.classList.add('valid');
                }
            }
        });
        
        // Remove error styling on input
        input.addEventListener('input', function() {
            this.classList.remove('error');
            const fieldGroup = this.closest('.form-group');
            const existingError = fieldGroup.querySelector('.error-message');
            if (existingError) {
                existingError.remove();
            }
        });
    });
    
    // Form submission handling
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (!validateForm()) {
                // Scroll to first error
                const firstError = document.querySelector('.error');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
                return;
            }
            
            // Show loading state
            const originalButtonText = submitButton.innerHTML;
            submitButton.innerHTML = 'Sending... <span class="loading-spinner">⟳</span>';
            submitButton.disabled = true;
            
            // Add loading spinner animation
            const spinner = submitButton.querySelector('.loading-spinner');
            if (spinner) {
                spinner.style.cssText = `
                    display: inline-block;
                    animation: spin 1s linear infinite;
                `;
            }
            
            // Submit form (Netlify will handle this automatically)
            const formData = new FormData(contactForm);
            
            fetch('/', {
                method: 'POST',
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams(formData).toString()
            })
            .then(() => {
                // Show success message
                showSuccessMessage();
                contactForm.reset();
            })
            .catch((error) => {
                console.error('Error:', error);
                showErrorMessage();
            })
            .finally(() => {
                // Reset button
                submitButton.innerHTML = originalButtonText;
                submitButton.disabled = false;
            });
        });
    }
    
    function showSuccessMessage() {
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message';
        successDiv.innerHTML = `
            <div style="
                background: #10b981;
                color: white;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                margin: 1rem 0;
                text-align: center;
                font-weight: 500;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            ">
                ✓ Thank you for your message! We'll get back to you soon.
            </div>
        `;
        
        contactForm.parentNode.insertBefore(successDiv, contactForm.nextSibling);
        
        // Remove success message after 5 seconds
        setTimeout(() => {
            successDiv.remove();
        }, 5000);
        
        // Scroll to success message
        successDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    
    function showErrorMessage() {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message-global';
        errorDiv.innerHTML = `
            <div style="
                background: #dc2626;
                color: white;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                margin: 1rem 0;
                text-align: center;
                font-weight: 500;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            ">
                ⚠ There was an error sending your message. Please try again or contact us directly.
            </div>
        `;
        
        contactForm.parentNode.insertBefore(errorDiv, contactForm.nextSibling);
        
        // Remove error message after 5 seconds
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }
    
    // Smooth scrolling for any anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add scroll-based animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.contact-section, .industry-context').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
        observer.observe(el);
    });
    
    // Add CSS for additional styles
    const additionalStyles = document.createElement('style');
    additionalStyles.textContent = `
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .form-input.error,
        .form-textarea.error {
            border-color: #dc2626;
            box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.1);
        }
        
        .form-input.valid,
        .form-textarea.valid {
            border-color: #10b981;
        }
        
        .logo-placeholder {
            transition: transform 0.3s ease-in-out;
        }
        
        .logo-placeholder:hover {
            transform: scale(1.05);
        }
    `;
    document.head.appendChild(additionalStyles);
    
    // Console message for developers
    console.log('🌱 Decarbonisation Industrial - Landing Page Loaded');
    console.log('Built with modern web standards for optimal performance and accessibility');
});

// Utility function for future enhancements
window.DecarbonisationIndustrial = {
    version: '1.0.0',
    contact: {
        email: 'contact@decarbonisationindustrial.com'
    },
    init: function() {
        console.log('Decarbonisation Industrial utilities initialized');
    }
};

